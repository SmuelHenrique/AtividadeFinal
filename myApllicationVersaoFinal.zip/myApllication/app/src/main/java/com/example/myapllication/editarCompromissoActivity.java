package com.example.myapllication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class editarCompromissoActivity extends AppCompatActivity {
    EditText txtNomeEditarCompromisso, txtDataEditarCompromisso, txtDescricaoEditarCompromisso;
    Button btnEditarCompromisso;
    Intent intent;
    Integer id;
    String login, idusuario;
    private SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editar_compromisso);
        intent = getIntent();
        login = intent.getStringExtra("login");
        id = intent.getIntExtra("id", 0);

        txtNomeEditarCompromisso = (EditText) findViewById(R.id.txtNomeEditarCompromisso);
        txtDataEditarCompromisso = (EditText) findViewById(R.id.txtDataEditarCompromisso);
        txtDescricaoEditarCompromisso = (EditText) findViewById(R.id.txtDescricaoEditarCompromisso);
        btnEditarCompromisso = (Button) findViewById(R.id.btnEditarCompromisso);
        carregarDados();

        btnEditarCompromisso.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditarCompromisso();
            }
        });
    }

    public void EditarCompromisso(){
        if (TextUtils.isEmpty(txtNomeEditarCompromisso.getText().toString())
                || TextUtils.isEmpty(txtDataEditarCompromisso.getText().toString())
                || TextUtils.isEmpty(txtDescricaoEditarCompromisso.getText().toString())){

            Toast.makeText(this, "Insira Valores para atualiza-los", Toast.LENGTH_SHORT).show();
        } else {
            try{
                bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
                String sql = "UPDATE compromisso SET nomeCompromisso=?, dataCompromisso=?, descricaoCompromisso=? " +
                        "WHERE compromissoLogin=? AND id = ?";
                SQLiteStatement stmt = bancoDados.compileStatement(sql);
                stmt.bindString(1,txtNomeEditarCompromisso.getText().toString());
                stmt.bindString(2,txtDataEditarCompromisso.getText().toString());
                stmt.bindString(3,txtDescricaoEditarCompromisso.getText().toString());
                stmt.bindString(4,login);
                stmt.bindString(5, idusuario);
                stmt.executeUpdateDelete();
                bancoDados.close();
                finish();

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void carregarDados(){
        try {
            bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
            Cursor cursor = bancoDados.rawQuery("SELECT nomeCompromisso, dataCompromisso, descricaoCompromisso, id " +
                    "FROM compromisso WHERE id = " + id.toString(), null);
            cursor.moveToFirst();
            txtNomeEditarCompromisso.setText(cursor.getString(0));
            txtDataEditarCompromisso.setText(cursor.getString(1));
            txtDescricaoEditarCompromisso.setText(cursor.getString(2));
            idusuario = (cursor.getString(3));

        } catch (Exception e){
            e.printStackTrace();
        }
    }
}