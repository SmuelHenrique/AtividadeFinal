package com.example.myapllication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class principalActivity extends AppCompatActivity {
    EditText txtNomeCompromisso,txtData, txtDescricaoCompromisso;
    Button btnCadastrarCompromissos, btnVerCompromissos, btnConta;
    Intent intent;
    String login;
    private SQLiteDatabase bancoDados;
    // private SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_principal);
        intent = getIntent();
        login = intent.getStringExtra("login");
        criarBancoDadosCompromissos();

        txtNomeCompromisso = (EditText) findViewById(R.id.txtNomeCompromisso);
        txtData = (EditText) findViewById(R.id.txtData);
        txtDescricaoCompromisso = (EditText) findViewById(R.id.txtDescricaoCompromisso);
        btnCadastrarCompromissos = (Button) findViewById(R.id.btnInserir);
        btnConta = (Button) findViewById(R.id.btnConta);
        btnVerCompromissos = (Button) findViewById(R.id.btnVerCompromissos);



        btnCadastrarCompromissos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(txtNomeCompromisso.getText().toString())
                    || TextUtils.isEmpty(txtData.getText().toString())
                    || TextUtils.isEmpty(txtDescricaoCompromisso.getText().toString()))
                {
                    Toast.makeText(null, "Preencha os campos", Toast.LENGTH_SHORT).show();
                } else {
                    try {
                        bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
                        String sql = "INSERT INTO compromisso (nomeCompromisso, dataCompromisso, descricaoCompromisso,compromissoLogin) " +
                                "VALUES (?, ?, ?, ?)";
                        SQLiteStatement stmt = bancoDados.compileStatement(sql);
                        stmt.bindString(1, txtNomeCompromisso.getText().toString());
                        stmt.bindString(2, txtData.getText().toString());
                        stmt.bindString(3, txtDescricaoCompromisso.getText().toString());
                        stmt.bindString(4, login);
                        stmt.executeInsert();
                        bancoDados.close();
                        txtNomeCompromisso.setText("");
                        txtData.setText("");
                        txtDescricaoCompromisso.setText("");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }
        });

        btnVerCompromissos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTelaCompromissos();
            }
        });

        btnConta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTelaEditar();
            }
        });

    }

    public void abrirTelaEditar(){
        Intent intent = new Intent(this, editarActivity.class);
        intent.putExtra("login",login);
        startActivity(intent);
    }

    public void criarBancoDadosCompromissos(){
        try {
            bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS compromisso (" +
                    "id INTEGER PRIMARY KEY AUTOINCREMENT" +
                    ", nomeCompromisso VARCHAR " +
                    ", dataCompromisso DATE" +
                    ", descricaoCompromisso VARCHAR" +
                    ", compromissoLogin VARCHAR" +
                    ", FOREIGN KEY (compromissoLogin) REFERENCES usuario (login) ON DELETE CASCADE)");

            bancoDados.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void abrirTelaCompromissos(){
        Intent intent = new Intent(this, compromissoActivity.class);
        intent.putExtra("login",login);
        startActivity(intent);
    }

    public void abrirTelaPrincipal(){
        Intent intent = new Intent(this, principalActivity.class);
        startActivity(intent);
    }
}