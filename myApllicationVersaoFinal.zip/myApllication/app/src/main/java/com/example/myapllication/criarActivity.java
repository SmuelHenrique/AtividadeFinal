package com.example.myapllication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class criarActivity extends AppCompatActivity {
    EditText txtEmailC, txtSenhaC, txtSenhaCorfirmarC;
    Button btnCadastrar;
    private SQLiteDatabase bancoDados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criar);

        txtEmailC = (EditText) findViewById(R.id.txtEmailEditar);
        txtSenhaC = (EditText) findViewById(R.id.txtSenhaEditar);
        txtSenhaCorfirmarC = (EditText) findViewById(R.id.txtSenhaConfirmarEditar);
        btnCadastrar = (Button) findViewById(R.id.btnCadastrar);

        btnCadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cadastrarUsuario();
            }
        });
    }

    public void cadastrarUsuario(){
        if(TextUtils.isEmpty(txtEmailC.getText().toString())
                || TextUtils.isEmpty(txtSenhaC.getText().toString())
                || TextUtils.isEmpty(txtSenhaCorfirmarC.getText().toString())) {
            Toast.makeText(this, "Erro", Toast.LENGTH_SHORT).show();
        }
        else {
            if (txtSenhaC.getText().toString().equals(txtSenhaCorfirmarC.getText().toString())) {

                try {
                    bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
                    String sql = "INSERT INTO usuario (login, senha) VALUES (?, ?)";
                    SQLiteStatement stmt = bancoDados.compileStatement(sql);
                    stmt.bindString(1, txtEmailC.getText().toString());
                    stmt.bindString(2, txtSenhaC.getText().toString());
                    stmt.executeInsert();
                    bancoDados.close();
                    finish();
                    voltarTelaLogin();
                } catch (Exception e) {
                    e.printStackTrace();
                }

            } else {
                Toast.makeText(this, "As senhas devem ser as mesmas", Toast.LENGTH_SHORT).show();
            }

        }
    }
    public void voltarTelaLogin(){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}