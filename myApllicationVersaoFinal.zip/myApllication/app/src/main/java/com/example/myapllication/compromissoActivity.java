package com.example.myapllication;

// Intuito da tela compromissos
    // Deve exibir os compromissos cadastrados pelos usuários
        // Deve existir um listView que exiba os dados
        // Deve existir uma função de listar dados
            // Ele deve fazer um select no banco onde o dono da tarefa corresponde ao login do email
            // O login do dono da tarefa vem como um intent da tela anterior
    // Deve existir a possibilidade de excluir essa tarefa caso segure por muito tempo
        // A função de excluir por um longo tempo se resume na função onlongclick

// Deve existir a possibilidade de editar essa tarefa caso toque na tarefa
        // Com o click rápido será aberta uma nova tela de edição
            // Essa tela possuirá a função de carregar os dados
                // Os dados serão caregados através de um id único que é passado por intent
            // Essa tela possuirá a função de editar os dados
                // Quando os dados forem editados ele retornará à tela principal

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

public class compromissoActivity extends AppCompatActivity {
    ListView listCompromissos;
    Button btnVoltar;
    Integer idSelecionado;
    public ArrayList<Integer> arrayIds;
    public SQLiteDatabase bancoDados;
    Intent intent;
    String login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compromisso);
        intent = getIntent();
        login = intent.getStringExtra("login");

        listCompromissos = (ListView) findViewById(R.id.listCompromisso);
        btnVoltar = (Button) findViewById(R.id.btnVoltar);

        listarDados();

        btnVoltar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        listCompromissos.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                excluir(i);
                return true;
            }
        });

        listCompromissos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                abrirTelaEditarCompromisso(i);
            }
        });
    }

    public void abrirTelaPrincipal(){
        Intent intent = new Intent(this, principalActivity.class);
        startActivity(intent);
    }

    public void listarDados(){
        try {

            bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
            Cursor meuCursor = bancoDados.rawQuery("SELECT id, nomeCompromisso, dataCompromisso " +
                    "FROM compromisso WHERE compromissoLogin = '" + login + "'", null);
            ArrayList<String> linhas = new ArrayList<String>();
            ArrayAdapter meuAdapter = new ArrayAdapter<String>(
                    this,
                    android.R.layout.simple_list_item_1,
                    android.R.id.text1,
                    linhas
            );
            listCompromissos.setAdapter(meuAdapter);
            arrayIds = new ArrayList<>();
            meuCursor.moveToFirst();
            do {
                linhas.add(meuCursor.getString(1) + " - " + meuCursor.getString(2));
                arrayIds.add(meuCursor.getInt(0));
            } while(meuCursor.moveToNext());

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    @Override
    protected void onResume(){
        super.onResume();
        listarDados();
    }

    public void excluir(Integer i){
        try{
            bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
            String sql = "DELETE FROM compromisso WHERE id =?";
            SQLiteStatement stmt = bancoDados.compileStatement(sql);
            stmt.bindLong(1, arrayIds.get(i));
            stmt.executeUpdateDelete();
            listarDados();
            bancoDados.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void abrirTelaEditarCompromisso(Integer i){
        Intent intent = new Intent(this, editarCompromissoActivity.class);
        intent.putExtra("id",arrayIds.get(i));
        intent.putExtra("login",login);
        startActivity(intent);
    }
}