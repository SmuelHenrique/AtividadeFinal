package com.example.myapllication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteStatement;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText txtEmail, txtSenha;
    Button btnEntrar, btnCriar;
    private SQLiteDatabase bancoDados;

    // Tela de Login
    // Eu recebo os dados que o usuário inseriu
    //Caso ele clique no Entrar eu devo verificar no banco se ele tem cadastro
        // Caso tenha cadastro envio ele para outra tela
        // Caso não tenha devo exibir uma mensagem de erro, e sugerir a criação de uma conta
    //Caso ele clique em Criar conta devo enviá-lo para uma tela de cadastro
        // Lá ele deve inserir uma email e senha
        // Caso e email seja novo a conta é criada e ele é enviado para a tela inicial novamente
        // Caso sua senha não confira ele deve exibir uma mensage
    //Já na tela principal ele pode ter a possibilidade de excluir e alterar seu cadastro

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtEmail = (EditText) findViewById(R.id.txtEmail);
        txtSenha = (EditText) findViewById(R.id.txtSenha);
        btnEntrar = (Button) findViewById(R.id.btnEntrar);
        btnCriar = (Button) findViewById(R.id.btnCriar);

        criarBancoDados();

        btnEntrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                verificarBanco();

            }
        });

        btnCriar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                abrirTelaCadastro();
            }
        });
    }

    public void criarBancoDados(){
        try {
            bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);
            bancoDados.execSQL("CREATE TABLE IF NOT EXISTS usuario(" +
                    " login VARCHAR PRIMARY KEY " +
                    ", senha VARCHAR)");

            bancoDados.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void abrirTelaCadastro(){
        Intent intent = new Intent(this, criarActivity.class);
        startActivity(intent);
    }
    public void verificarBanco(){
        try {

            bancoDados = openOrCreateDatabase("usuarios", MODE_PRIVATE, null);

            Cursor meuCursor = bancoDados.rawQuery("SELECT login FROM usuario " +
                    "WHERE login = '"+txtEmail.getText().toString()+"' " +
                    "AND senha = '"+txtSenha.getText().toString()+"' ", null);

            meuCursor.moveToFirst();
            if (meuCursor.getCount()>0){
                abrirTelaPrincipal();
            } else {
                Toast.makeText(this, "Esse cadastro nao existe", Toast.LENGTH_SHORT).show();
            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }
    public void abrirTelaPrincipal(){
        Intent intent = new Intent(this, principalActivity.class);
        intent.putExtra("login", txtEmail.getText().toString());
        startActivity(intent);
    }
}